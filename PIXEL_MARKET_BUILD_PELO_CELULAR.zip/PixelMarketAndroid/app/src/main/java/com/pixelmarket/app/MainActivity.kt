package com.pixelmarket.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var pendingCameraUri: Uri? = null

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) processImage(uri) else showStatus("Foto não capturada. Tente novamente.")
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) processImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(NativeScannerBridge(), "NativeScanner")
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class NativeScannerBridge {
        @JavascriptInterface
        fun openCamera() {
            runOnUiThread {
                try {
                    val imageFile = File(cacheDir, "pixel_market_${System.currentTimeMillis()}.jpg")
                    val uri = FileProvider.getUriForFile(
                        this@MainActivity,
                        "$packageName.fileprovider",
                        imageFile
                    )
                    pendingCameraUri = uri
                    cameraLauncher.launch(uri)
                } catch (e: Exception) {
                    showStatus("Não foi possível abrir a câmera.")
                }
            }
        }

        @JavascriptInterface
        fun openGallery() {
            runOnUiThread {
                try {
                    galleryLauncher.launch("image/*")
                } catch (e: Exception) {
                    showStatus("Não foi possível abrir a galeria.")
                }
            }
        }
    }

    private fun processImage(uri: Uri) {
        showStatus("Analisando etiqueta offline…")
        Thread {
            val bitmap = try {
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            } catch (_: Exception) { null }

            if (bitmap == null) {
                showStatus("Não foi possível abrir essa imagem.")
                return@Thread
            }

            runOnUiThread { runOnDeviceRecognition(bitmap) }
        }.start()
    }

    private fun runOnDeviceRecognition(bitmap: Bitmap) {
        val image = try { InputImage.fromBitmap(bitmap, 0) } catch (_: Exception) {
            showStatus("Imagem inválida.")
            return
        }

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val barcodeOptions = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
            .build()
        val barcodeScanner = BarcodeScanning.getClient(barcodeOptions)

        var textResult = JSONObject()
        var barcodeValue = ""
        val remaining = AtomicInteger(2)

        fun finishOne() {
            if (remaining.decrementAndGet() == 0) {
                textResult.put("barcode", barcodeValue)
                val payload = JSONObject.quote(textResult.toString())
                webView.post {
                    webView.evaluateJavascript("window.onNativeScanResult && window.onNativeScanResult($payload);", null)
                }
                recognizer.close()
                barcodeScanner.close()
            }
        }

        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                val lines = JSONArray()
                val fullText = StringBuilder()
                for (block in visionText.textBlocks) {
                    for (line in block.lines) {
                        val box = line.boundingBox
                        val item = JSONObject()
                        item.put("text", line.text)
                        item.put("top", box?.top ?: 0)
                        item.put("left", box?.left ?: 0)
                        item.put("width", box?.width() ?: 0)
                        item.put("height", box?.height() ?: 0)
                        lines.put(item)
                        fullText.append(line.text).append('\n')
                    }
                }
                textResult = JSONObject()
                textResult.put("text", fullText.toString())
                textResult.put("lines", lines)
                finishOne()
            }
            .addOnFailureListener {
                textResult = JSONObject()
                textResult.put("text", "")
                textResult.put("lines", JSONArray())
                finishOne()
            }

        barcodeScanner.process(image)
            .addOnSuccessListener { barcodes ->
                barcodeValue = barcodes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue ?: ""
                finishOne()
            }
            .addOnFailureListener { finishOne() }
    }

    private fun showStatus(message: String) {
        val quoted = JSONObject.quote(message)
        webView.post { webView.evaluateJavascript("document.getElementById('ocrStatus').textContent=$quoted;", null) }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
