# Gerar o APK pelo celular (sem computador)

Este projeto pode ser compilado em um servidor GitHub Actions usando apenas o navegador do celular.

1. Extraia este ZIP no celular.
2. No navegador, entre em https://github.com e crie uma conta ou entre na sua conta.
3. Crie um repositório novo chamado `pixel-market-android` (pode ser privado).
4. Envie para o repositório todos os arquivos e pastas que estão dentro de `PixelMarketAndroid`, incluindo a pasta oculta `.github` e o arquivo `settings.gradle.kts`. Não envie apenas a pasta ZIP.
5. Abra a aba **Actions** do repositório. Se pedir, habilite GitHub Actions.
6. Selecione **Build Pixel Market APK** e toque em **Run workflow**.
7. Aguarde o trabalho terminar com marca verde. Abra a execução concluída e baixe o artefato **Pixel-Market-APK**.
8. Extraia o ZIP baixado e toque em `app-debug.apk` para instalar. O Android poderá pedir autorização para instalar apps dessa origem.

A compilação ocorre nos servidores do GitHub; o APK de teste é assinado para depuração. Não publique esse APK como versão de loja.
