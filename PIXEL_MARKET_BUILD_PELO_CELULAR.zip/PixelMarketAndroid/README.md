# PIXEL MARKET — aplicativo Android offline

Este projeto transforma a interface Pixel Market em um app Android nativo com a página HTML/CSS/JS embutida em `app/src/main/assets/index.html`.

## O que funciona sem internet depois de instalado
- Abrir a câmera nativa do aparelho e fotografar a etiqueta.
- Escolher imagens existentes na galeria.
- OCR local no aparelho (Google ML Kit Text Recognition, modelo bundled).
- Leitura local de códigos de barras e QR Codes (ML Kit Barcode Scanning bundled).
- Extração das linhas reconhecidas, sugestão de nome/preço/unidade.
- Editar nome, preço e quantidade, adicionar/remover produtos.
- Soma automática e armazenamento local da lista no WebView.
- Interface e fontes sem chamadas a CDNs.

## Gerar o APK
1. Instale o Android Studio.
2. Abra a pasta `PixelMarketAndroid` no Android Studio.
3. Aguarde o Gradle sincronizar. **A internet é necessária apenas para baixar as ferramentas e dependências na primeira compilação.**
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste será criado em `app/build/outputs/apk/debug/app-debug.apk`.

Após a instalação, o uso normal do aplicativo e os modelos de OCR/código de barras são locais e não precisam de internet.

## Detalhes técnicos
- Package: `com.pixelmarket.app`
- Min Android: API 23 (Android 6.0)
- Interface: WebView com HTML local
- Scanner: ML Kit nativo com modelos bundled no APK
- Câmera/galeria: Activity Result APIs + FileProvider

## Limitações honestas
- O OCR pode errar em etiquetas desfocadas, refletivas, inclinadas ou com impressão apagada. O aplicativo deixa os campos editáveis para conferência.
- O reconhecimento do código de barras retorna a numeração; descobrir descrição comercial exige uma base de produtos, que não é incluída porque teria de ser embarcada e atualizada.
- Este ambiente de criação não possui Android SDK nem Gradle instalados. Por isso, foi possível montar o projeto Android Studio, mas **não compilar nem validar um APK final aqui**. O APK deve ser gerado pelo Android Studio seguindo os passos acima.
